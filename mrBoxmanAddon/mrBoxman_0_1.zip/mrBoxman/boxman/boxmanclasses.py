"""
Contains the basic boxman DTO contracts and serialization
"""
import traceback

import bpy
from enum import Enum
import json
from json import JSONEncoder
import zlib
import inspect
from abc import ABC


class IStaticDictionaryListable(ABC):

    @classmethod
    def list_attributes(cls) -> list:
        attributes = inspect.getmembers(cls, lambda a: not (inspect.isroutine(a)))
        elements = [a[0] for a in attributes if '_' not in a[0]]
        return elements


class BoxmanEncoder(JSONEncoder):
    """
    Tells the json serializer how to handle the boxman classes
    """

    def default(self, o):
        return o.__dict__


# region Exceptions


class NotABoxmamException(Exception):
    """
    Raised when trying to operate over a mesh that can be used.
    """

    def __init__(self):
        super(NotABoxmamException).__init__("Object is not MrBoxman compatible!")


class NotInLibraryException(Exception):
    """
    When trying to use a key for an object that is not in the loaded dictionary.
    """

    def __init__(self, key: str):
        super(NotInLibraryException, self).__init__(f"The key: '{key}' is not "
                                                               f"present in the MrBoxman library!")


# endregion

# region Enums


class BoxmanFileTypes(IStaticDictionaryListable):
    """
    Lists the constants and prefixes used in the whole addon
    """

    BOXMAN_OBJECT_TYPE: str = "bxmo"
    BOXMAN_LIBRARY_TYPE: str = "bxml"


class BoxmanPrefixes(IStaticDictionaryListable):
    """
    Lists the constants and prefixes used in the whole addon
    """

    BOXMAN: str = "bxm"
    BOXMAN_GENERIC_DESC: str = "bxm_obj"


class BoxmanJointTypes(IStaticDictionaryListable):
    """
    Lists the constants and prefixes used in the whole addon
    """

    DEFAULT: str = "DEFAULT"
    OBJECT_ROOT: str = "OBJECT_ROOT"


class BoxmanOrientations(IStaticDictionaryListable):
    """
    Lists the orientation constants used in the whole addon
    """

    L: str = "L"
    R: str = "R"
    C: str = "C"


# endregion


class BoxmanProperties:
    """
    properties of a boxman object
    """

    PROP_IS_BOXMAN: str = "is_boxman"
    PROP_ORIENTATION: str = "boxman_orientation"
    PROP_BOXMAN_NAME: str = "boxman_name"
    PROP_JOINT_TYPE: str = "boxman_jointType"
    PROP_BOXMAN_DESCRIPTION = "boxman_description"

    def __init__(self):
        self.name = BoxmanPrefixes.BOXMAN
        self.orientation = BoxmanOrientations.C
        self.joint_type = BoxmanJointTypes.DEFAULT
        self.description = BoxmanPrefixes.BOXMAN


class BoxmanMeshDTO:
    """
    Basic mesh contract form
    """

    def __init__(self):
        self.location = []
        self.scale = []
        self.rotations = []
        self.vertex_list = []
        self.polygon_list = []
        self.properties = BoxmanProperties()

    def q_is_root(self) -> bool:
        """
        Tells if the boxman object can be used to root some transformations
        """
        return True

    def get_object_name(self) -> str:
        """
        Gets the name of the blander object that is linked to the boxman dto instance
        """
        return f"{BoxmanPrefixes.BOXMAN}.{self.properties.orientation}.{self.properties.name}"

    @staticmethod
    def get_object_name_from_object(cls, obj):
        """
        Uses operates over a boxman compatible object to get its correct name
        """
        if obj.get(BoxmanProperties.PROP_IS_BOXMAN) is None:
            raise NotABoxmamException()

        orientation = obj.get(BoxmanProperties.PROP_ORIENTATION)
        name = obj.get(BoxmanProperties.PROP_BOXMAN_NAME)
        return f"{BoxmanPrefixes.BOXMAN}.{orientation}.{name}"

    def serialize(self, minify: bool = True):
        """
        Gets a string representation of the boxman object, used for exporting.
        The Minify parameter tels if the serialization is indented or not (for readability)
        """

        if not minify:
            return json.dumps(self, indent=4, cls=BoxmanEncoder)
        else:
            return self.__str__()

    def __str__(self):
        return BoxmanEncoder().encode(self)


class BoxmanDTO(BoxmanMeshDTO):

    def __init__(self, mesh_data: BoxmanMeshDTO = None):
        super().__init__()
        self.children = []
        if not mesh_data is None:
            self.location = mesh_data.location
            self.scale = mesh_data.scale
            self.rotations = mesh_data.rotations
            self.vertex_list = mesh_data.vertex_list
            self.polygon_list = mesh_data.polygon_list
            self.properties = mesh_data.properties

    def q_is_root(self) -> bool:
        root = self.properties.joint_type
        return root == BoxmanJointTypes.OBJECT_ROOT

    def chain_reverse_orientation(self) -> None:
        """
        Reverses the orientation property of the current instance and all its children
        """

        # take the target, get the reverse name, check if exist
        options = {
            BoxmanOrientations.L: BoxmanOrientations.R,
            BoxmanOrientations.R: BoxmanOrientations.L,
            BoxmanOrientations.C: BoxmanOrientations.C
        }

        self.properties.orientation = options[self.properties.orientation]
        for child in self.children:
            child.chain_reverse_orientation()


def load_boxman_mesh_from_object(obj) -> BoxmanMeshDTO:
    """
    Creates a boxman mesh object from a context object object.
    """

    if obj.get(BoxmanProperties.PROP_IS_BOXMAN) is None:
        raise NotABoxmamException()

    ret = BoxmanMeshDTO()
    ret.properties.name = obj[BoxmanProperties.PROP_BOXMAN_NAME]
    ret.properties.orientation = obj[BoxmanProperties.PROP_ORIENTATION]
    ret.properties.joint_type = obj[BoxmanProperties.PROP_JOINT_TYPE]
    ret.properties.description = obj[BoxmanProperties.PROP_BOXMAN_DESCRIPTION]

    # temps
    obj_location = obj.location
    obj_rotation = obj.rotation_euler
    obj_scale = obj.scale
    obj_data_vertices = obj.data.vertices
    obj_data_polygons = obj.data.polygons

    ret.location = [obj_location[0], obj_location[1], obj_location[2]]
    ret.scale = [obj_scale[0], obj_scale[1], obj_scale[2]]
    ret.rotations = [[obj_rotation.x, obj_rotation.y, obj_rotation.z], obj_rotation.order]
    ret.vertex_list = []
    ret.polygon_list = []
    for vert in obj_data_vertices:
        ret.vertex_list.append([vert.co[0], vert.co[1], vert.co[2]])
    for poly in obj_data_polygons:
        polygon = []
        for index in poly.vertices:
            polygon.append(index)
        ret.polygon_list.append(polygon)

    return ret


def load_boxman_from_object(obj) -> BoxmanDTO:
    """
    Creates a boxman dto from a context object object.
    """

    loader = load_boxman_mesh_from_object(obj)
    ret = BoxmanDTO(loader)
    if len(obj.children) > 0:
        for child in obj.children:
            ret.children.append(load_boxman_from_object(child))
    return ret


def construct_boxman_from_json(json_object: dict) -> BoxmanDTO:
    """
    Creates a boxman dto from a dictionary
    """

    ret = BoxmanDTO()
    ret.location = json_object["location"]
    ret.scale = json_object["scale"]
    ret.rotations = json_object["rotations"]
    ret.vertex_list = json_object["vertex_list"]
    ret.polygon_list = json_object["polygon_list"]
    ret.properties.name = json_object["properties"]["name"]
    ret.properties.orientation = json_object["properties"]["orientation"]
    ret.properties.joint_type = json_object["properties"]["joint_type"]
    ret.properties.description = json_object["properties"]["description"]

    kids = json_object["children"]
    ret.children = []
    for cc in kids:
        ret.children.append(construct_boxman_from_json(cc))
    return ret


def show_message_box(message="", title="MrBoxman", icon='INFO'):
    """
    Uses the bpy interface to show a popup message
    """

    def draw(self, context):
        self.layout.label(text=message)

    bpy.context.window_manager.popup_menu(draw, title=title, icon=icon)


class StringCompressor:
    """
    This class compresses strings in different formats
    """

    @staticmethod
    def compress(element: str) -> str:
        """Compresses a string encoding it as UTF-8"""
        a = element.encode("UTF-8")
        return zlib.compress(a).hex()

    @staticmethod
    def decompress(element: bytes) -> str:
        """Decompresses a UTF-8 string"""
        return zlib.decompress(element).decode("UTF-8")


class BoxmanTemplateLibrary:
    """
    This contains dictionaries of templated names and the compressed string serializations
    """

    def __init__(self):
        self.library_name = "template_library"
        self.template_objects: dict = {}
        self.object_descriptions = {}

    def get_boxman_object(self, key: str) -> BoxmanDTO:
        """
        Gets a boxman dto from the dictionary
        """

        if key not in self.template_objects:
            raise NotInLibraryException(key)

        raw_text = self.template_objects[key]
        json_text = StringCompressor.decompress(bytes.fromhex(raw_text))
        dd = json.loads(json_text)
        return construct_boxman_from_json(dd)

    def serialize(self, minify: bool = True):
        """
        Gets a string representation if the dictionary
        """

        if not minify:
            return json.dumps(self, indent=4, cls=BoxmanEncoder)
        else:
            return self.__str__()

    def __str__(self):
        return BoxmanEncoder().encode(self)


def deserialize_library(serialized: str) -> BoxmanTemplateLibrary:
    """
    Gets an instance of the library from a serialized dictionary
    """

    json_object = json.loads(serialized)
    ret = BoxmanTemplateLibrary()
    ret.library_name = json_object["library_name"]
    ret.template_objects = json_object["template_objects"]
    ret.object_descriptions = json_object["object_descriptions"]
    return ret


def standard_except_operation(ex: Exception):
    """
    Used to show the error message on cached exceptions.
    """

    print("Execution failed!")
    traceback.print_exc()
    print(ex)
    show_message_box(ex.__str__(), "Cached exception", "ERROR")
    raise ex



